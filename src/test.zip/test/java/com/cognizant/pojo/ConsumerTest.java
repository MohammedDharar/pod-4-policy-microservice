package com.cognizant.pojo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class ConsumerTest {

	Consumer consumer = new Consumer();
	Consumer consumer1 = new Consumer(2,"Gayatri", "Kutemate", new Date(), "Business.pvt",
			"ABCD1234k","gayatri@gmail.com", "1234567890", "Nagpur", "Sam", 101);
	
	@Test
	void getAgentIdTest() {
		consumer.setAgentId(101);
		assertEquals(101, consumer.getAgentId());
	}

	@Test
	public void testToString() {
		String expected ="Consumer [consumerId=" + 2 + ", firstName=" + "Gayatri" + ", lastName=" + "Kutemate" + ", dob="
				+ new Date() + ", businessName=" + "Business.pvt" + ", panDetails=" + "ABCD1234k" + ", email=" + "gayatri@gmail.com"
				+ ", phone=" + "1234567890" + ", address=" + "Nagpur" + ", agentName=" + "Sam" + ", agentId=" + 101
				+ "]";
		assertEquals(expected, consumer1.toString());
	}
}
