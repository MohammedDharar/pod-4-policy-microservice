package com.cognizant.pojo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

class QuotesMasterTest {

	QuotesMaster quotesMaster =new QuotesMaster();
	QuotesMaster quotes = new QuotesMaster(1,2,6,"equipment","20,000 INR");
	
	@Test
	void testGettersSetters() {
		quotesMaster.setId(2);
		quotesMaster.setBusinessValue(5);
		quotesMaster.setPropertyValue(5);
		quotesMaster.setPropertyType("Inventory");
		quotesMaster.setQuotes("30,000 INR");
		
		assertEquals(2, quotesMaster.getId());
		assertEquals(5,quotesMaster.getBusinessValue());
		assertEquals(5, quotesMaster.getPropertyValue());
		assertEquals("Inventory",quotesMaster.getPropertyType());
		assertEquals("30,000 INR",quotesMaster.getQuotes());
	}
	
	@Test
	public void testToString() {
		
		        
		        String expected = "QuotesMaster [id=" + 1 + ", businessValue=" + 2 + ", propertyValue=" + 6
						+ ", propertyType=" + "equipment" + ", quotes=" + "20,000 INR" + "]"; // put the expected value here
		        Assert.assertEquals(expected, quotes.toString());
		    }
	

}
