package com.cognizant.pojo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

class PropertyTest {

	Property property = new Property();
	Property property1 = new Property(1, 12, "Business Property Insurance", "Equipment",
				20000L, 2, "500", "building",
				2, 50000L, 20000L, 1);
	
	@Test
	void getPropertyValuetest() {
		property.setPropertyValue(9);
		assertEquals(9, property.getPropertyValue());
	}

	@Test
	void getPropertyTypetest() {
		property.setPropertyType("Building");
		assertEquals("Building", property.getPropertyType());
	}
	
	@Test
	public void testToString() {
		String expected = "Property [id=" + 1 + ", businessId=" + 12 + ", insuranceType=" + "Business Property Insurance"
				+ ", propertyType=" + "Equipment" + ", annualDepreciationValue=" + 20000L
				+ ", propertyValue=" + 2 + ", buildingsqft=" + "500" + ", buildingType="
				+ "building" + ", buildingAge=" + 2 + ", costOfAsset=" + 50000L + ", salvageValue="
				+ 20000L + ", usefulLifeOfAsset=" + 1 + "]";
		assertEquals(expected, property1.toString());
	}
}
