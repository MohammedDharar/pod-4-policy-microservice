package com.cognizant.pojo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BusinessTest {

	private Business business= new Business();
	private Business business1= new Business(1, 2, "Rental",500000L,
			100000L, 123, 3, 5) ;
		
	
	@Test
	public void getBusinessValueTest() {
		business.setBusinessValue(5);
		assertEquals(5,business.getBusinessValue() );
		
	}
	@Test
	public void testTostring() {
		String expected="Business [businessId=" + 1 + ", consumerId=" + 2 + ", businessCategory="
				+ "Rental" + ", businessTurnOver=" + 500000L + ", capitalInvested=" + 100000L
				+ ", totalEmployees=" + 123 + ", businessValue=" + 3 + ", businessAge="
				+ 5 + "]";
		
		assertEquals(expected, business1.toString());
	}
	
}
