package com.cognizant.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cognizant.exception.PolicyNotFoundException;
import com.cognizant.model.PolicyMaster;
import com.cognizant.service.PolicyService;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class PolicyMicroserviceTest {
	
//	@InjectMocks
//	PolicyMicroserviceController policyMicroserviceController ;
//	
//	@Mock
//   PolicyService policyService;
//	
//	@Mock
//	   PolicyMaster policyMaster1;
//	PolicyMaster policyMaster;
//	
//	
//	@Test
//	void test() throws PolicyNotFoundException {
//		
//		MockHttpServletRequest request = new MockHttpServletRequest();
//        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
//        policyMaster=new PolicyMaster("p07", "industrial", "builder", 30000L, "4 years", 4, 6, "chennai", "insurancetype");
//        //when(policyService.getPolicyMaster((Integer)4,(Integer)6)).thenReturn(policyMaster1);
//        //System.out.println(policyMaster1.getConsumerType());
//		//assertEquals(policyMaster, policyMaster1);
//	}

}
