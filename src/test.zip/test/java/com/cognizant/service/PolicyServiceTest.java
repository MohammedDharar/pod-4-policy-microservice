package com.cognizant.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.model.ConsumerPolicy;
import com.cognizant.model.PolicyMaster;
import com.cognizant.repository.ConsumerPolicyRepo;
import com.cognizant.repository.PolicyMasterRepo;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class PolicyServiceTest {
	@Mock
	private ConsumerPolicyRepo consumerPolicyRepo;
	@Mock
	private PolicyMasterRepo policyMasterRepo;
	@InjectMocks
	private PolicyService policyService;

	///private ConsumerPolicy consumerPolicy;
	private PolicyMaster policyMaster;

	private ConsumerPolicy consumerPolicy = new ConsumerPolicy((Integer) 200,(Integer) 12,"P04","building","Owner",20000L,"2 weeks",(Integer)2,(Integer)6,"Pune","Rental","accepted","ka", new Date(),"20000 INR","paid",(Integer)10);
	@BeforeEach
	void init() {
		ConsumerPolicy consumerPolicy = new ConsumerPolicy((Integer) 2,(Integer) 12,"P04","building","Owner",20000L,"2 weeks",(Integer)2,(Integer)6,"Pune","Rental","accepted","ka", new Date(),"20000 INR","paid",(Integer)10);
		consumerPolicyRepo.save(consumerPolicy);
		policyMaster = new PolicyMaster("p07", "industrial", "builder", 30000L, "4 years", 4, 6, "chennai",
				"insurancetype");
		policyMasterRepo.save(policyMaster);
	}

	@Test
	void getPolicyServiceTest() {
		Mockito.when(policyMasterRepo.findByBusinessValueAndPropertyValue((Integer) 2, (Integer) 2)).thenReturn(
				new PolicyMaster("p07", "industrial", "builder", 30000L, "4 years", 4, 6, "chennai", "insurancetype"));
		assertEquals(policyMaster, policyMaster);
	}

	@Test
	void getConsumerServiceTest() {
		Mockito.when(consumerPolicyRepo.findByConsumerIdAndBusinessId((Integer) 2, (Integer) 2))
				.thenReturn(new ConsumerPolicy( (Integer) 2,(Integer) 12,"P04","building","Owner",20000L,"2 weeks",(Integer)2,(Integer)6,"Pune","Rental","accepted","ka", new Date(),"20000 INR","paid",(Integer)10));
		assertEquals(consumerPolicy,consumerPolicy);
	}
	

	
}