	package com.cognizant.exception;

	import static org.junit.jupiter.api.Assertions.assertEquals;

	import org.junit.jupiter.api.Test;
	import org.springframework.boot.test.context.SpringBootTest;

	/**
	 * Test - PolicyNotFoundException class
	 */
	@SpringBootTest
	class PolicyNotFoundExceptionTest {

		@Test
		void testPolicyNotFoundException() {
			PolicyNotFoundException policyNotFoundException = new PolicyNotFoundException(
					"Policy Not Found");
			assertEquals("Policy Not Found", policyNotFoundException.getMessage());
		}

	}


