package com.cognizant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Test - GlobalExceptionHandler class
 */
@SpringBootTest
class GlobalExceptionHandlerTest {

	@Autowired
	private GlobalExceptionHandler globalExceptionHandler;

	private ApiErrorResponse apiErrorResponse;

	@BeforeEach
	void setUp() {
		apiErrorResponse = new ApiErrorResponse();
	}

	

	@Test
	void handlesQuotesNotFoundExceptionTest() {
		 PolicyNotFoundException   policyNotFoundException  = new  PolicyNotFoundException (
				"Quotes Not found");
		globalExceptionHandler.handlePolicyNotFoundException( policyNotFoundException);
		apiErrorResponse.setMessage( policyNotFoundException.getMessage());
		apiErrorResponse.setLocalizedMessage( policyNotFoundException.getLocalizedMessage());
		ResponseEntity<?> entity = new ResponseEntity<>(apiErrorResponse, HttpStatus.UNAUTHORIZED);
		assertEquals(401, entity.getStatusCode().value());
	}

}
