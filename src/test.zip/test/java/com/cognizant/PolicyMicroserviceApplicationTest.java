package com.cognizant;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyMicroserviceApplicationTest {

	@Test
	void test() throws IOException{
		
				PolicyMicroserviceApplication.main(new String[] {});
				assertTrue(true);
		
	}

}
