package com.cognizant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Instant;
import java.util.Date;

import org.junit.Before;
import org.junit.jupiter.api.Test;

public class ConsumerPolicyTest {

	private ConsumerPolicy consumerPolicy=new ConsumerPolicy();
	private Date date = new Date();

	private ConsumerPolicy consumerPolicytest=new ConsumerPolicy((Integer) 2,(Integer) 12,"P04","building","Owner",20000L,"2 weeks",(Integer)2,(Integer)6,"Pune","Rental","accepted","ka", date,"20000 INR","paid",(Integer)10);

	
	
	
	@Test
	@Before
	public void testGettersSetters() {
		consumerPolicy.setConsumerId(1);
		consumerPolicy.setBusinessId(2);
		consumerPolicy.setAcceptanceStatus("accepted");
		consumerPolicy.setAcceptedQuotes("20,000 INR");
		consumerPolicy.setAgentId(101);
		consumerPolicy.setBaseLocation("Pune");
		consumerPolicy.setBusinessValue(2);
		consumerPolicy.setConsumerType("Owner");
		consumerPolicy.setCoveredSum(200000L);
		consumerPolicy.setDuration("2 weeks");
		consumerPolicy.setEffectiveDate(date);
		consumerPolicy.setPaymentStatus("paid");
		consumerPolicy.setPolicyId("P01");
		consumerPolicy.setPropertyType("Building");
		consumerPolicy.setPropertyValue(2);
		consumerPolicy.setTypes("pay back");
		consumerPolicy.setStatus("Initiated");
		
		
		assertEquals(1, consumerPolicy.getConsumerId());
		assertEquals(2, consumerPolicy.getBusinessId());
		assertEquals("accepted", consumerPolicy.getAcceptanceStatus());
		assertEquals("20,000 INR", consumerPolicy.getAcceptedQuotes());
		assertEquals(101, consumerPolicy.getAgentId());
		assertEquals("Pune", consumerPolicy.getBaseLocation());
		assertEquals(2, consumerPolicy.getBusinessValue());
		assertEquals("Owner", consumerPolicy.getConsumerType());
		assertEquals(200000L, consumerPolicy.getCoveredSum());
		assertEquals("2 weeks", consumerPolicy.getDuration());
		assertEquals(date, consumerPolicy.getEffectiveDate());
		assertEquals("paid", consumerPolicy.getPaymentStatus());
		assertEquals("P01", consumerPolicy.getPolicyId());
		assertEquals("Building", consumerPolicy.getPropertyType());
		assertEquals(2, consumerPolicy.getPropertyValue());
		assertEquals("pay back", consumerPolicy.getTypes());
		assertEquals("Initiated", consumerPolicy.getStatus());
	}

	//ConsumerPolicy((Integer) 2,(Integer) 12,"P04","building","Owner",20000L,"2 weeks",(Integer)2,(Integer)6,"Pune","Rental",
	//"accepted","ka", new Date(),"20000 INR","paid",(Integer)10);
	@Test
	public void testToString() {
		String expected= "ConsumerPolicy [consumerId=" + 2 + ", businessId=" + 12 + ", policyId=" + "P04"
				+ ", propertyType=" + "building" + ", consumerType=" + "Owner" + ", coveredSum=" + 20000L
				+ ", duration=" + "2 weeks" + ", businessValue=" + 2 + ", propertyValue=" + 6
				+ ", baseLocation=" + "Pune" + ", types=" + "Rental" + ", status=" + "accepted" + ", acceptanceStatus="
				+ "ka" + ", effectiveDate=" + date + ", acceptedQuotes=" + "20000 INR"
				+ ", paymentStatus=" + "paid" + ", agentId=" + 10 + "]";
		
		assertEquals(expected, consumerPolicytest.toString());
	}



}
