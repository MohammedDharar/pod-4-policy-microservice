package com.cognizant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class PolicyMasterTest {

	PolicyMaster policyMaster = new PolicyMaster();
	PolicyMaster policyMasterTest = new PolicyMaster("P07", "industrial", "builder", 30000L, "4 years", 4, 6, "chennai",
			"insurancetype");

	@Test
	public void testGetterSetter() {

		policyMaster.setPolicyId("P010");
		policyMaster.setBusinessValue(2);
		policyMaster.setPropertyValue(2);
		policyMaster.setPropertyType("Building");
		policyMaster.setConsumerType("Owner");
		policyMaster.setTenure("1 year");
		policyMaster.setAssuredSum(20000L);
		policyMaster.setBaseLocation("Pune");
		policyMaster.setTypes("Pay back");

		assertEquals("P010", policyMaster.getPolicyId());
		assertEquals(2, policyMaster.getBusinessValue());
		assertEquals(2, policyMaster.getPropertyValue());
		assertEquals("Building", policyMaster.getPropertyType());
		assertEquals("Owner", policyMaster.getConsumerType());
		assertEquals("1 year", policyMaster.getTenure());
		assertEquals(20000L, policyMaster.getAssuredSum());
		assertEquals("Pune", policyMaster.getBaseLocation());
		assertEquals("Pay back", policyMaster.getTypes());
	}

//("P07","industrial", "builder",30000L,"4 years",4,6 ,"chennai","insurancetype")
	@Test
	public void testToString() {
		String expected = "PolicyMaster [" + "policyId=" + "P07" + ", propertyType=" + "industrial" + ", consumerType="
				+ "builder" + ", assuredSum=" + 30000L + ", tenure=" + "4 years" + ", businessValue=" + 4
				+ ", propertyValue=" + 6 + ", baseLocation=" + "chennai" + ", types=" + "insurancetype" + "]";
		assertEquals(expected, policyMasterTest.toString());
	}
}
